# LUXE DROP — Shopify Theme

A custom Shopify theme converted from your original HTML design. Fully editable via the Shopify Theme Editor.

---

## How to Upload to GitHub and Connect to Shopify

### Step 1 — Upload to GitHub

1. Go to [github.com](https://github.com) and sign in (or create a free account).
2. Click **New repository**.
3. Name it `luxe-drop-theme`, set it to **Private**, and click **Create repository**.
4. On your computer, open a terminal in this folder and run:

```bash
git init
git add .
git commit -m "Initial theme upload"
git remote add origin https://github.com/YOUR_USERNAME/luxe-drop-theme.git
git push -u origin main
```

---

### Step 2 — Connect GitHub to Shopify

1. Go to your **Shopify Admin** → **Online Store** → **Themes**.
2. Click **Add theme** → **Connect from GitHub**.
3. Authorize Shopify to access your GitHub account.
4. Select the `luxe-drop-theme` repository and the `main` branch.
5. Click **Connect**.
6. Shopify will pull the theme. Once it appears, click **Preview** to check it, then **Publish** to go live.

---

## Editing Your Theme in Shopify

After publishing, go to **Online Store → Themes → Customize** to edit:

| Section | What you can change |
|---|---|
| **Announcement Bar** | The text shown at the top |
| **Header** | Logo text, navigation menu |
| **Hero** | Heading, subheading, buttons, featured product card |
| **Product Grid** | Which collection to show, how many products |
| **Features Strip** | Icons, titles, subtitles (add/remove blocks) |
| **Promo Banner** | Sale heading, countdown, button |
| **Testimonials** | Add/edit/remove review blocks |
| **Newsletter** | Heading and subtext |
| **Footer** | Logo, description, social links, menu columns |

---

## Theme File Structure

```
luxe-drop-theme/
├── assets/
│   ├── theme.css          ← All styles
│   └── theme.js           ← All JavaScript
├── config/
│   ├── settings_schema.json
│   └── settings_data.json
├── layout/
│   └── theme.liquid       ← Main wrapper (head + body)
├── locales/
│   └── en.default.json
├── sections/
│   ├── announcement-bar.liquid
│   ├── cart-drawer.liquid
│   ├── features-strip.liquid
│   ├── footer.liquid
│   ├── header.liquid
│   ├── hero.liquid
│   ├── newsletter.liquid
│   ├── product-grid.liquid
│   ├── promo-banner.liquid
│   ├── testimonials.liquid
│   └── ticker-bar.liquid
└── templates/
    ├── index.liquid        ← Home page
    ├── collection.liquid   ← Collection pages
    └── product.liquid      ← Product pages
```
