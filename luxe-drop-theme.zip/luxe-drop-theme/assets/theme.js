// ── LUXE DROP THEME JS ──

const TICKER_ITEMS = [
  '🌎 Global Shipping','✦ 50K+ Happy Customers','🔒 Secure Checkout','↩️ 30-Day Returns',
  '⚡ Flash Sales Daily','💎 Verified Quality','🚚 Free Shipping $75+','📦 Fast Dispatch',
];

let cart = [];
let wishlist = [];

// ── TICKER ──
function buildTicker() {
  const track = document.getElementById('tickerTrack');
  if (!track) return;
  const items = [...TICKER_ITEMS, ...TICKER_ITEMS];
  track.innerHTML = items.map(t => `
    <span class="ticker-item">${t}<span class="ticker-dot"></span></span>`).join('');
}

// ── PARTICLES ──
function buildParticles() {
  const container = document.getElementById('heroParticles');
  if (!container) return;
  for (let i = 0; i < 18; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.cssText = `left:${Math.random()*100}%;top:${Math.random()*100}%;animation-duration:${4+Math.random()*6}s;animation-delay:${Math.random()*4}s;opacity:${.2+Math.random()*.4};width:${Math.random()>.5?2:3}px;height:${Math.random()>.5?2:3}px;`;
    container.appendChild(p);
  }
}

// ── CART ──
function addToCart(name, price, emoji, cat, variantId) {
  const existing = cart.find(i => i.name === name);
  if (existing) {
    existing.qty++;
  } else {
    cart.push({ name, price, emoji, cat, qty: 1, variantId });
  }
  updateCartUI();
  showToast(`${emoji} "${name}" added to cart!`);

  // Send to Shopify cart API if variantId is provided
  if (variantId) {
    fetch('/cart/add.js', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: variantId, quantity: 1 })
    }).catch(console.error);
  }
}

function updateCartUI() {
  const total = cart.reduce((s, i) => s + i.qty, 0);
  const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);

  const countEl = document.getElementById('cartCount');
  if (countEl) {
    countEl.textContent = total;
    countEl.classList.remove('bump');
    void countEl.offsetWidth;
    countEl.classList.add('bump');
  }

  const cartQty = document.getElementById('cartQty');
  const cartTotal = document.getElementById('cartTotal');
  if (cartQty) cartQty.textContent = total;
  if (cartTotal) cartTotal.textContent = '$' + subtotal.toFixed(2);

  const itemsEl = document.getElementById('cartItems');
  const footerEl = document.getElementById('cartFooter');
  if (!itemsEl) return;

  if (cart.length === 0) {
    itemsEl.innerHTML = `<div class="cd-empty"><div class="cd-empty-icon">🛍️</div><div style="font-size:16px;font-weight:600;color:var(--ink)">Your cart is empty</div><div>Add some products to get started</div><button class="btn-primary" style="margin-top:12px;font-size:12px;" onclick="closeCart()">Continue Shopping</button></div>`;
    if (footerEl) footerEl.style.display = 'none';
  } else {
    itemsEl.innerHTML = cart.map((item, idx) => `
      <div class="cart-item">
        <div class="ci-img">${item.emoji}</div>
        <div class="ci-info">
          <div class="ci-name">${item.name}</div>
          <div class="ci-var">${item.cat}</div>
          <div class="ci-row">
            <div class="ci-qty">
              <button class="qty-btn" onclick="changeQty(${idx}, -1)">−</button>
              <span class="qty-n">${item.qty}</span>
              <button class="qty-btn" onclick="changeQty(${idx}, 1)">+</button>
            </div>
            <span class="ci-price">$${(item.price * item.qty).toFixed(2)}</span>
          </div>
          <span class="ci-remove" onclick="removeItem(${idx})">Remove</span>
        </div>
      </div>`).join('');
    if (footerEl) footerEl.style.display = 'block';
  }
}

function changeQty(idx, delta) {
  cart[idx].qty += delta;
  if (cart[idx].qty <= 0) cart.splice(idx, 1);
  updateCartUI();
}

function removeItem(idx) {
  cart.splice(idx, 1);
  updateCartUI();
}

function openCart() {
  document.getElementById('cartDrawer')?.classList.add('open');
  document.getElementById('overlay')?.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeCart() {
  document.getElementById('cartDrawer')?.classList.remove('open');
  document.getElementById('overlay')?.classList.remove('open');
  document.body.style.overflow = '';
}

function checkout() {
  // Redirect to Shopify checkout
  window.location.href = '/checkout';
}

// ── WISHLIST ──
function toggleWishItem(id, e) {
  if (e) e.stopPropagation();
  const idx = wishlist.indexOf(id);
  if (idx >= 0) {
    wishlist.splice(idx, 1);
    showToast('💔 Removed from wishlist');
  } else {
    wishlist.push(id);
    showToast('❤️ Added to wishlist!');
  }
  const wc = document.getElementById('wishCount');
  if (wc) {
    wc.textContent = wishlist.length;
    wc.style.display = wishlist.length ? 'flex' : 'none';
  }
}

function toggleWishlist() {
  showToast(`❤️ ${wishlist.length} item${wishlist.length !== 1 ? 's' : ''} in wishlist`);
}

// ── TOAST ──
let toastTimer;
function showToast(msg, icon = '✅') {
  const t = document.getElementById('toast');
  if (!t) return;
  document.getElementById('toastMsg').textContent = msg;
  document.getElementById('toastIcon').textContent = icon;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 3000);
}

// ── NEWSLETTER ──
function subscribeNewsletter() {
  const email = document.getElementById('nlEmail')?.value;
  if (!email || !email.includes('@')) { showToast('⚠️ Please enter a valid email', '⚠️'); return; }
  showToast('🎉 Welcome! Check your inbox for a 15% off code!');
  document.getElementById('nlEmail').value = '';
}

// ── COUNTDOWN ──
function setCountdown() {
  const end = new Date();
  end.setHours(23, 59, 59, 0);
  function tick() {
    const now = new Date();
    let diff = Math.max(0, end - now) / 1000;
    const h = Math.floor(diff / 3600); diff %= 3600;
    const m = Math.floor(diff / 60);
    const s = Math.floor(diff % 60);
    const cdH = document.getElementById('cdH');
    const cdM = document.getElementById('cdM');
    const cdS = document.getElementById('cdS');
    if (cdH) cdH.textContent = String(h).padStart(2,'0');
    if (cdM) cdM.textContent = String(m).padStart(2,'0');
    if (cdS) cdS.textContent = String(s).padStart(2,'0');
  }
  tick();
  setInterval(tick, 1000);
}

// ── SCROLL EFFECTS ──
window.addEventListener('scroll', () => {
  const progress = window.scrollY / (document.body.scrollHeight - window.innerHeight);
  const sp = document.getElementById('scrollProgress');
  if (sp) sp.style.width = (progress * 100) + '%';

  const header = document.getElementById('header');
  if (header) header.classList.toggle('scrolled', window.scrollY > 40);

  const btt = document.getElementById('backToTop');
  if (btt) btt.classList.toggle('visible', window.scrollY > 300);
});

// ── INTERSECTION OBSERVER ──
const io = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.style.opacity = '1';
      e.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: .1 });

function observeElements() {
  document.querySelectorAll('.feature-item, .testimonial-card, .product-card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(24px)';
    el.style.transition = 'opacity .6s ease, transform .6s ease';
    io.observe(el);
  });
}

// ── CATEGORY FILTER (for index page) ──
const catRow = document.getElementById('catRow');
if (catRow) {
  catRow.addEventListener('click', e => {
    const pill = e.target.closest('.cat-pill');
    if (!pill) return;
    document.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
    pill.classList.add('active');
    filterProducts(pill.dataset.cat);
  });
}

function filterProducts(filter) {
  const cards = document.querySelectorAll('.product-card[data-cat]');
  cards.forEach(card => {
    card.style.display = (filter === 'all' || card.dataset.cat === filter) ? '' : 'none';
  });
}

// ── SEARCH ──
const searchInput = document.getElementById('searchInput');
if (searchInput) {
  searchInput.addEventListener('input', e => {
    const q = e.target.value.toLowerCase();
    const cards = document.querySelectorAll('.product-card[data-name]');
    cards.forEach(card => {
      const match = !q || card.dataset.name.toLowerCase().includes(q) || card.dataset.cat.toLowerCase().includes(q);
      card.style.display = match ? '' : 'none';
    });
  });
}

// ── INIT ──
document.addEventListener('DOMContentLoaded', () => {
  buildTicker();
  buildParticles();
  setCountdown();
  updateCartUI();
  setTimeout(observeElements, 300);
});
